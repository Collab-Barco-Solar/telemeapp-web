#ifndef __WIFI_H__
#define __WIFI_H__

#include <Arduino.h>
#include <WiFi.h>

void init_wifi();

#endif
