#ifndef __DADOS_MPPT_H__
#define __DADOS_MPPT_H__

void init_mppt();
String get_dados_mppt();


#endif
