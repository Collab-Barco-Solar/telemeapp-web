/* Connections:
    MPPT pin     MPPT        ESP         ESP pin
    1            GND         GND         GND
    2            RX          TX          -              usar APENAS se for desejável enviar informaçoes (programar) o mppt. Para mais informações, ler documento XXXXX.
    3            TX          RX          16
    4            Power+      none        -              não usar!
*/

#include "dados_MPPT.h"
struct struct
{
  int intvalor_medido;
  String label, val;
  String CS7 =  "";
  String ERR1 = "     Geen";
  String CS0 =  "      Uit";  //estado de operação - strings
  String CS2 =  "     Fout";
  String CS3 =  "     Bulk";
  String CS4 =  "Absorptie";
  String CS5 =  "  Druppel";
  char tensao_bateria[6];
  char corrente_carregamento[6]; // CORRENTE DE CARREGAMENTO
  char energia_painel[6]; //ENERGIA DO PAINEL
  char estado_carregamento[12]; //ESTADO DE CARREGAMENTO
  char mensagem_erro[12]; //MENSAGEM DE ERRO
  char rendimento_ontem[6]; //RENDIMENTO ONTEM
  char potencia_ontem[6]; //PODER ONTEM
  char rendimento_hoje[6]; //RENDIMENTO HOJE
} dadosMPPT;

dadosMPPT dm;

#define RXD2 16
#define TXD2 17

void init_MPPT(void)
{
  Serial2.begin(19200, SERIAL_8N1, RXD2, TXD2);
}

void read_MPPT(dadosMPPT &dm)
{
  if (Serial2.available())
  {
    label = Serial2.readStringUntil('\t');                // this is the actual line that reads the label from the MPPT controller
    val = Serial2.readStringUntil('\r\r\n');              // this is the line that reads the value of the label
    float valor_medido; //VALOR MEDIDO
    char buf[45];
    //Serial.print("label: ");
    //Serial.println(label);
    //Serial.print("value: ");
    //Serial.println(val);
    if (label == "I")                                           // I chose to select certain paramaters that were good for me. check the Victron whitepaper for all labels.
    {                                                           // In this case I chose to read charging current
      val.toCharArray(buf, sizeof(buf));                        // conversion of val to a character array. Don't ask me why, I saw it in one of the examples of Adafruit and it works.
      valor_medido = atof(buf);                           // conversion to float
      valor_medido = valor_medido / 1000;                       // calculating the correct value, see the Victron whitepaper for details. The value of label I is communicated in milli amps.
      dtostrf(valor_medido, len, 2, dm->corrente_carregamento);              // conversion of calculated value to string
      dm->corrente_carregamento[len] = ' '; 
      dm->corrente_carregamento[len + 1] = 0;
      //Serial.print("Corrente: ");
      //Serial.println(corrente_carregamento);
    }
    else if (label == "V")
    {
      val.toCharArray(buf, sizeof(buf));                    // By studying these small routines, you can modify to reading the parameters you want,
      valor_medido = atof(buf);                               // converting them to the desired value (milli-amps to amps or whatever)
      valor_medido = valor_medido / 1000;
      dtostrf(valor_medido, len, 2, dm->tensao_bateria);          // setting color scheme etc.
      dm->tensao_bateria[len] = ' '; 
      dm->tensao_bateria[len + 1] = 0;
      //Serial.print("Tensao bateria: ");
      //Serial.println(tensao_bateria);
    }
    else if (label == "VPV")
    {
      val.toCharArray(buf, sizeof(buf));                    // By studying these small routines, you can modify to reading the parameters you want,
      valor_medido = atof(buf);
      valor_medido = valor_medido / 1000; // converting them to the desired value (milli-amps to amps or whatever)
      dtostrf(valor_medido, len, 2, dm->energia_painel);          // setting color scheme etc.
      dm->energia_painel[len] = ' '; 
      dm->energia_painel[len + 1] = 0;
      //Serial.print("Tensao Painel: ");
      //Serial.println(energia_painel);
    }
    else if (label == "H22")
    {
      val.toCharArray(buf, sizeof(buf));
      float valor_medido = atof(buf);
      valor_medido = valor_medido / 100;
      dtostrf(valor_medido, len, 2, dm->rendimento_ontem);
      dm->rendimento_ontem[len] = ' '; 
      dm->rendimento_ontem[len + 1] = 0;
      //Serial.print("H22: ");
      //Serial.println(rendimento_ontem);
    }
    else if (label == "H20")
    {
      val.toCharArray(buf, sizeof(buf));
      float valor_medido = atof(buf);
      valor_medido = valor_medido / 100;
      dtostrf(valor_medido, len, 2, dm->rendimento_hoje);
      dm->rendimento_hoje[len] = ' '; 
      dm->rendimento_hoje[len + 1] = 0;
      //Serial.print("H20: ");
      //Serial.println(potencia_ontem);
    }
    else if (label == "H23")
    {
      val.toCharArray(buf, sizeof(buf));
      valor_medido = atof(buf);
      dtostrf(valor_medido, len, 0, dm->potencia_ontem);
      dm->potencia_ontem[len] = ' '; 
      dm->potencia_ontem[len + 1] = 0;
      //Serial.print("H23: ");
      //Serial.println(potencia_ontem);
    }
    else if (label == "ERR")                               // This routine reads the error code. If there is no error, "Geen" will be printed. See line 24 of this sketch
    {                                                      // else the actual error code will be printed. Refer to the Victron whitepaper for reference.
      val.toCharArray(buf, sizeof(buf));
      intvalor_medido = atoi(buf);
      if (intvalor_medido == 0)
      {
        ERR1.toCharArray(mensagem_erro, len);
      }
      else if (intvalor_medido != 0)
      {
        itoa (mensagem_erro, intvalor_medido, 12);
      }

    }
    else if (label == "CS")                                  // this routine reads Charge Status, see lines 25 - 29
    {
      val.toCharArray(buf, sizeof(buf));
      intvalor_medido = atoi(buf);
      if (intvalor_medido == 0)
      {
        CS0.toCharArray(estado_carregamento, len);
      }
      else if (intvalor_medido == 2)
      {
        CS2.toCharArray(estado_carregamento, len);
      }
      else if (intvalor_medido == 3)
      {
        CS3.toCharArray(estado_carregamento, len);
      }
      else if (intvalor_medido == 4)
      {
        CS4.toCharArray(estado_carregamento, len);
      }
      else if (intvalor_medido == 5)
      {
        CS5.toCharArray(estado_carregamento, len);
      }
      dm->estado_carregamento[len] = ' '; 
      dm->estado_carregamento[len + 1] = 0;

      //Serial.print("CS: ");
      //Serial.println(estado_carregamento);
    }
  }
}

void get_dados_MPPT()
{
  String result = "";
  result = String(dm->tensao_bateria) + "," + String(dm->corrente_carregamento) + "," + String(dm->energia_painel) + "," + String(dm->rendimento_hoje)
            + String(dm->estado_carregamento) + "," + String(dm->mensagem_erro);
//dados->rendimento_ontem; //RENDIMENTO ONTEM
//dados->potencia_ontem; //PODER ONTEM

  unsigned long currentTime = millis();
  if ((unsigned long)(currentTime - previousMPPTUpdate) >= UPDATE_PERIOD_MS)
  {
    read_MPPT(dm);
    
    // RESET timer
    previousMPPTUpdate = millis();
  }
  return result;
}
